print("Importing requests...")
import requests
print("Importing moviepy...")
from moviepy import ImageClip, AudioFileClip, concatenate_videoclips, VideoFileClip, CompositeAudioClip, afx
print("Importing edge_tts...")
import edge_tts
print("Importing elevenlabs...")
from elevenlabs.client import ElevenLabs
print("Done utils debug.")
